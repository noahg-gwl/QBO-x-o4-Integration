'use strict';

console.log('Hello world');
