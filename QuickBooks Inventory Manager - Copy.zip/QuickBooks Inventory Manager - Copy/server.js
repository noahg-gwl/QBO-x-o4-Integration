const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const path = require('path');
const OpenAI = require('openai');

const app = express();
app.use(bodyParser.json());
app.use(express.static('public'));

// Load environment variables from a .env file
require('dotenv').config();

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
});

let accessToken = process.env.ACCESS_TOKEN;
let realmId = process.env.REALM_ID; // Store the realm ID

// Function to generate a random state parameter
function generateState() {
    return crypto.randomBytes(16).toString('hex');
}

// Handle GET request to the root URL
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Redirect to QuickBooks for authorization
app.get('/auth', (req, res) => {
    const state = generateState();
    const authUri = `https://appcenter.intuit.com/connect/oauth2?client_id=${process.env.CLIENT_ID}&redirect_uri=${process.env.REDIRECT_URI}&response_type=code&scope=${process.env.SCOPES}&state=${state}`;
    res.redirect(authUri);
});

// Handle the authorization callback from QuickBooks
app.get('/callback', async (req, res) => {
    const authCode = req.query.code;
    const state = req.query.state; // Capture the state parameter

    // Verify the state parameter here if you saved it during the /auth request

    try {
        const response = await axios.post('https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer', {
            code: authCode,
            redirect_uri: process.env.REDIRECT_URI,
            grant_type: 'authorization_code'
        }, {
            auth: {
                username: process.env.CLIENT_ID,
                password: process.env.CLIENT_SECRET
            },
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        });

        accessToken = response.data.access_token;
        realmId = req.query.realmId;
        res.send(`Access Token: ${accessToken}`);
    } catch (error) {
        res.send('Error: ' + error.response.data);
    }
});

// Fetch and display company info from QuickBooks
app.get('/company', async (req, res) => {
    try {
        const response = await axios.get(`https://sandbox-quickbooks.api.intuit.com/v3/company/${realmId}/companyinfo/${realmId}`, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Accept': 'application/json'
            }
        });

        // Log the API response for debugging
        console.log('API Response:', response.data);

        res.json(response.data);
    } catch (error) {
        console.error('Error fetching company info:', error.response.data);
        res.send('Error: ' + error.response.data);
    }
});

// Fetch customers from QuickBooks
app.get('/customers', async (req, res) => {
    try {
        const response = await axios.get(`https://sandbox-quickbooks.api.intuit.com/v3/company/${realmId}/query?query=SELECT * FROM Customer`, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Accept': 'application/json'
            }
        });

        res.json(response.data.QueryResponse.Customer || []);
    } catch (error) {
        console.error('Error fetching customers:', error.response.data);
        res.send('Error: ' + error.response.data);
    }
});

// Fetch invoices from QuickBooks
app.get('/invoices', async (req, res) => {
    try {
        const response = await axios.get(`https://sandbox-quickbooks.api.intuit.com/v3/company/${realmId}/query?query=SELECT * FROM Invoice`, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Accept': 'application/json'
            }
        });

        res.json(response.data.QueryResponse.Invoice || []);
    } catch (error) {
        console.error('Error fetching invoices:', error.response.data);
        res.send('Error: ' + error.response.data);
    }
});

// Add a new product to the catalog
app.post('/products', async (req, res) => {
    const product = req.body;

    try {
        const response = await axios.post(`https://sandbox-quickbooks.api.intuit.com/v3/company/${realmId}/item`, product, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        });

        res.json(response.data);
    } catch (error) {
        console.error('Error adding product:', error.response.data);
        res.send('Error: ' + error.response.data);
    }
});

// View all products in the catalog
app.get('/products', async (req, res) => {
    try {
        const response = await axios.get(`https://sandbox-quickbooks.api.intuit.com/v3/company/${realmId}/query?query=SELECT * FROM Item`, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Accept': 'application/json'
            }
        });

        res.json(response.data.QueryResponse.Item || []);
    } catch (error) {
        console.error('Error fetching products:', error.response.data);
        res.send('Error: ' + error.response.data);
    }
});

// Delete a product from the catalog
app.delete('/products/:id', async (req, res) => {
    const productId = req.params.id;

    try {
        const response = await axios.post(`https://sandbox-quickbooks.api.intuit.com/v3/company/${realmId}/item/${productId}?operation=delete`, {}, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        });

        res.json(response.data);
    } catch (error) {
        console.error('Error deleting product:', error.response.data);
        res.send('Error: ' + error.response.data);
    }
});

// Generate a quote using GPT-4
app.post('/generate-quote', async (req, res) => {
    const { text } = req.body;

    try {
        const response = await openai.chat.completions.create({
            model: "gpt-4",
            messages: [{ role: "user", content: text }],
            max_tokens: 1000,
        });

        res.json({ quote: response.choices[0].message.content });
    } catch (error) {
        console.error('Error generating quote:', error.response.data);
        res.send('Error: ' + error.response.data);
    }
});

app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
