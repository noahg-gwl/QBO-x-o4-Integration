const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const crypto = require('crypto');

console.log('Express:', typeof express !== 'undefined');
console.log('Axios:', typeof axios !== 'undefined');
console.log('Body-Parser:', typeof bodyParser !== 'undefined');
console.log('Crypto:', typeof crypto !== 'undefined');
